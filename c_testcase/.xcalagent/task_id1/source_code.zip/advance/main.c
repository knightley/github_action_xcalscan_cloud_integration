#include "global.h"

int main()
{
  test_aob();
  test_dbf();
  test_msf();
  test_npd();
  test_uaf();
  test_uiv();
  foo();
  memmodel_clang1();
}
